package com.dravesh.cscautosave

import android.app.Notification
import android.content.ContentProviderOperation
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class WhatsAppNotificationService : NotificationListenerService() {

    companion object {
        private const val WHATSAPP = "com.whatsapp"
        private const val PREFS = "csc"
        private const val NEXT = "next_number"
        private const val TAG = "last_saved"

        // Accepts formats such as:
        // +91 89359 57951
        // +918935957951
        // 89359 57951
        // 08935957951
        private val phoneRegex = Regex(
            """(?<!\d)(?:\+?\d[\d\s().-]{7,}\d)(?!\d)"""
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        val combined = "$title $text $bigText"
        val phone = extractPhone(combined) ?: return

        saveIfNew(phone)
    }

    private fun extractPhone(value: String): String? {
        val candidates = phoneRegex.findAll(value).map { it.value }.toList()

        for (raw in candidates) {
            val digits = raw.filter { it.isDigit() }
            if (digits.length < 10 || digits.length > 15) continue

            // Indian numbers from a +91 notification become 10 local digits.
            val normalized = when {
                digits.length == 12 && digits.startsWith("91") -> digits
                digits.length == 10 -> "91$digits"
                else -> digits
            }

            if (normalized.length in 10..15) return normalized
        }
        return null
    }

    private fun saveIfNew(phone: String) {
        val normalized = normalizePhone(phone)
        if (normalized.isBlank()) return
        if (hasPhone(normalized)) return

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var next = prefs.getInt(NEXT, 1)

        // Find a free CSC number in case a previous run was interrupted.
        var name = "CSC $next"
        while (hasContactName(name)) {
            next++
            name = "CSC $next"
        }

        try {
            val ops = ArrayList<ContentProviderOperation>()

            ops.add(
                ContentProviderOperation.newInsert(
                    ContactsContract.RawContacts.CONTENT_URI
                )
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )

            ops.add(
                ContentProviderOperation.newInsert(
                    ContactsContract.Data.CONTENT_URI
                )
                    .withValueBackReference(
                        ContactsContract.Data.RAW_CONTACT_ID, 0
                    )
                    .withValue(
                        ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                    )
                    .withValue(
                        ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                        name
                    )
                    .build()
            )

            ops.add(
                ContentProviderOperation.newInsert(
                    ContactsContract.Data.CONTENT_URI
                )
                    .withValueBackReference(
                        ContactsContract.Data.RAW_CONTACT_ID, 0
                    )
                    .withValue(
                        ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                    )
                    .withValue(
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        "+$normalized"
                    )
                    .withValue(
                        ContactsContract.CommonDataKinds.Phone.TYPE,
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                    )
                    .build()
            )

            contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)

            prefs.edit()
                .putInt(NEXT, next + 1)
                .putString(TAG, normalized)
                .apply()

        } catch (_: Exception) {
            // Permission or provider error. The next notification can retry.
        }
    }

    private fun normalizePhone(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        return when {
            digits.length == 10 -> "91$digits"
            digits.length == 12 && digits.startsWith("91") -> digits
            else -> digits
        }
    }

    private fun hasPhone(phone: String): Boolean {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phone)
        )

        val projection = arrayOf(ContactsContract.PhoneLookup._ID)
        val cursor: Cursor? = contentResolver.query(
            uri, projection, null, null, null
        )

        cursor.use { return it?.moveToFirst() == true }
    }

    private fun hasContactName(name: String): Boolean {
        val cursor = contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts._ID),
            "${ContactsContract.Contacts.DISPLAY_NAME} = ?",
            arrayOf(name),
            null
        )

        cursor.use { return it?.moveToFirst() == true }
    }
}
