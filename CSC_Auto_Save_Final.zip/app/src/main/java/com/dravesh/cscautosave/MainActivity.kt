package com.dravesh.cscautosave

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private val permissionCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()

        val title = TextView(this).apply {
            text = "📱 CSC Auto Save"
            textSize = 26f
            setPadding(pad, pad, pad, pad)
        }

        val info = TextView(this).apply {
            text = """
                WhatsApp के नए नंबर अपने Contacts में
                CSC 1, CSC 2, CSC 3... के नाम से save होंगे।

                1. Contacts permission दें
                2. Notification Access ON करें
                3. WhatsApp notifications ON रखें
            """.trimIndent()
            textSize = 17f
            setPadding(pad, 0, pad, pad)
        }

        val contactsButton = Button(this).apply {
            text = "Contacts Permission"
            setOnClickListener {
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(
                            Manifest.permission.READ_CONTACTS,
                            Manifest.permission.WRITE_CONTACTS
                        ),
                        permissionCode
                    )
                }
            }
        }

        val notificationButton = Button(this).apply {
            text = "Open Notification Access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        val status = TextView(this).apply {
            textSize = 15f
            setPadding(pad, pad, pad, pad)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(title)
            addView(info)
            addView(contactsButton)
            addView(notificationButton)
            addView(status)
        }

        setContentView(layout)
        updateStatus(status)
    }

    private fun updateStatus(status: TextView) {
        val prefs = getSharedPreferences("csc", MODE_PRIVATE)
        val next = prefs.getInt("next_number", 1)
        status.text = "अगला Contact: CSC $next"
    }
}
