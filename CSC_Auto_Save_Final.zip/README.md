# CSC Auto Save

Proper Android Studio project for automatically saving a new WhatsApp notification number as:
CSC 1, CSC 2, CSC 3...

## How it works
- Reads WhatsApp notification title/text.
- Looks for a phone number.
- Checks Contacts for an existing number.
- If it is new, creates a contact with the next CSC number.
- Repeated notifications for the same number do not create duplicates.

## Important limitation
This works only when the WhatsApp notification exposes a phone number. Some WhatsApp notifications show only a person's name, so no number can be extracted in those cases.

## Build
Open the `CSC_Auto_Save` folder in Android Studio and wait for Gradle Sync.
Then use Build > Build App Bundle(s) / APK(s) > Build APK(s).

## Permissions
The app requires:
- READ_CONTACTS
- WRITE_CONTACTS
- Notification Access

Do not grant permissions to an app you do not trust.
