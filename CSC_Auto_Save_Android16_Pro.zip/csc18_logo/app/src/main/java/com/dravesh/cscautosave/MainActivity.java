package com.dravesh.cscautosave;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Context;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private final BroadcastReceiver historyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(android.content.Context context, Intent intent) {
            refreshHistory();
        }
    };
    private static final int CONTACT_REQ = 41;
    private static final int ACCOUNT_REQ = 42;
    private HistoryDbHelper historyDb;
    private TextView historyList;
    private TextView historyCount;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            setContentView(R.layout.main);
            historyDb = new HistoryDbHelper(this);
            setupUi();
        } catch (Throwable t) {
            Toast.makeText(this, "CSC Auto Save start error: " + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void setupUi() {
        TextView status = findViewById(R.id.status);
        Button permission = findViewById(R.id.permission);
        Button notif = findViewById(R.id.notif);
        Button reset = findViewById(R.id.reset);
        Button account = findViewById(R.id.account);
        Button clearHistory = findViewById(R.id.clearHistory);
        Button settings = findViewById(R.id.settings);
        historyList = findViewById(R.id.historyList);
        historyCount = findViewById(R.id.historyCount);

        permission.setOnClickListener(v -> requestContacts());
        notif.setOnClickListener(v -> openNotificationSettings());
        account.setOnClickListener(v -> chooseGoogleAccount());
        reset.setOnClickListener(v -> {
            getSharedPreferences("csc", MODE_PRIVATE).edit().putInt("next", 1).apply();
            updateStatus();
            Toast.makeText(this, "CSC numbering 1 se start hogi", Toast.LENGTH_SHORT).show();
        });
        settings.setOnClickListener(v -> showSettings());
        clearHistory.setOnClickListener(v -> {
            historyDb.clearToday();
            refreshHistory();
            Toast.makeText(this, "Aaj ki history clear ho gayi", Toast.LENGTH_SHORT).show();
        });
        updateStatus();
        refreshHistory();
        updatePermissionButtons();
    }

    private void updatePermissionButtons() {
        Button permission = findViewById(R.id.permission);
        Button notif = findViewById(R.id.notif);
        Button account = findViewById(R.id.account);
        TextView setupComplete = findViewById(R.id.setupComplete);

        if (permission != null) {
            boolean contactsOk = android.os.Build.VERSION.SDK_INT < 23 ||
                    (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                     checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED);
            permission.setVisibility(contactsOk ? View.GONE : View.VISIBLE);
        }

        if (notif != null) {
            notif.setVisibility(isNotificationAccessEnabled() ? View.GONE : View.VISIBLE);
        }

        boolean accountOk = false;
        if (account != null) {
            String selected = getSharedPreferences("csc", MODE_PRIVATE).getString("google_account", null);
            accountOk = !TextUtils.isEmpty(selected);
            account.setVisibility(accountOk ? View.GONE : View.VISIBLE);
        }

        boolean contactsOk = android.os.Build.VERSION.SDK_INT < 23 ||
                (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                 checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED);
        boolean notifOk = isNotificationAccessEnabled();
        if (setupComplete != null) {
            setupComplete.setVisibility(contactsOk && notifOk && accountOk ? View.VISIBLE : View.GONE);
        }
    }

    private boolean isNotificationAccessEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        String myComponent = new android.content.ComponentName(this, WhatsAppNotificationListener.class).flattenToString();
        String myComponentShort = new android.content.ComponentName(this, WhatsAppNotificationListener.class).flattenToShortString();
        for (String item : enabled.split(":")) {
            if (myComponent.equalsIgnoreCase(item) || myComponentShort.equalsIgnoreCase(item)) return true;
        }
        return false;
    }

    private void updateStatus() {
        TextView s = findViewById(R.id.status);
        if (s != null) {
            String prefix = getSharedPreferences("csc", MODE_PRIVATE).getString("name_prefix", "CSC");
            if (prefix == null || prefix.trim().isEmpty()) prefix = "CSC";
            s.setText("Next contact: " + prefix.trim() + " " + getSharedPreferences("csc", MODE_PRIVATE).getInt("next", 1) + "  •  Google Contacts");
        }
        TextView active = findViewById(R.id.activeStatus);
        if (active != null) {
            boolean ready = (android.os.Build.VERSION.SDK_INT < 23 ||
                    (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                     checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED))
                    && isNotificationAccessEnabled()
                    && !TextUtils.isEmpty(getSharedPreferences("csc", MODE_PRIVATE).getString("google_account", null));
            active.setText(ready ? "READY" : "SETUP");
        }
    }

    private void refreshHistory() {
        if (historyDb == null || historyList == null) return;
        ArrayList<String> rows = historyDb.getTodayRows();
        if (historyCount != null) historyCount.setText("Aaj Saved: " + rows.size());
        if (rows.isEmpty()) {
            historyList.setText("Aaj abhi koi number save nahi hua.");
            return;
        }
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < rows.size(); i++) {
            out.append(i + 1).append(". ").append(rows.get(i));
            if (i < rows.size() - 1) out.append("\n\n");
        }
        historyList.setText(out.toString());
    }


    private void showSettings() {
        android.content.SharedPreferences prefs = getSharedPreferences("csc", MODE_PRIVATE);
        String current = prefs.getString("google_account", null);
        String accountText = TextUtils.isEmpty(current) ? "Not selected" : current;
        String prefix = prefs.getString("name_prefix", "CSC");
        if (TextUtils.isEmpty(prefix)) prefix = "CSC";
        boolean autoSave = prefs.getBoolean("auto_save", true);

        final String[] items = new String[]{
                "📧  Google Account\n    " + accountText,
                "🏷️  Contact Name Format\n    " + prefix + " 1, " + prefix + " 2, ...",
                "⚡  Auto Save\n    " + (autoSave ? "ON" : "OFF"),
                "🔄  Change Google Account",
                "🛡️  Duplicate Protection\n    Always ON",
                "📋  History\n    Name + Phone only",
                "🔎  Numbering\n    Selected Google account scan",
                "🧹  Reset Local Counter",
                "ℹ️  About CSC Auto Save"
        };

        new AlertDialog.Builder(this)
                .setTitle("⚙ CSC Pro Settings")
                .setItems(items, (dialog, which) -> {
                    if (which == 0 || which == 3) {
                        chooseGoogleAccount();
                    } else if (which == 1) {
                        showNamePrefixSettings();
                    } else if (which == 2) {
                        boolean now = !getSharedPreferences("csc", MODE_PRIVATE)
                                .getBoolean("auto_save", true);
                        getSharedPreferences("csc", MODE_PRIVATE).edit()
                                .putBoolean("auto_save", now).apply();
                        Toast.makeText(this, now ? "Auto Save ON" : "Auto Save OFF",
                                Toast.LENGTH_SHORT).show();
                    } else if (which == 7) {
                        new AlertDialog.Builder(this)
                                .setTitle("Reset Local Counter?")
                                .setMessage("Next save par app selected Google account ke existing contacts scan karke number dobara calculate karega.")
                                .setNegativeButton("Cancel", null)
                                .setPositiveButton("Reset", (d, w) -> {
                                    getSharedPreferences("csc", MODE_PRIVATE).edit()
                                            .putInt("next", 1).apply();
                                    Toast.makeText(this, "Counter reset. Existing Contacts safe hain.",
                                            Toast.LENGTH_SHORT).show();
                                }).show();
                    } else if (which == 8) {
                        new AlertDialog.Builder(this)
                                .setTitle("CSC Auto Save Pro")
                                .setMessage("WhatsApp number detect → selected Google account scan → next name number → phone-only contact → History.")
                                .setPositiveButton("OK", null).show();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showNamePrefixSettings() {
        String current = getSharedPreferences("csc", MODE_PRIVATE).getString("name_prefix", "CSC");
        if (TextUtils.isEmpty(current)) current = "CSC";
        final String[] options = {"CSC", "WORK", "XTZ", "CUSTOM"};
        int checked = 0;
        if (current.equalsIgnoreCase("WORK")) checked = 1;
        else if (current.equalsIgnoreCase("XTZ")) checked = 2;
        else if (!current.equalsIgnoreCase("CSC")) checked = 3;

        final int[] selected = {checked};
        new AlertDialog.Builder(this)
                .setTitle("Contact Name Format")
                .setSingleChoiceItems(options, checked, (dialog, which) -> {
                    selected[0] = which;
                    if (which != 3) {
                        String chosen = options[which];
                        getSharedPreferences("csc", MODE_PRIVATE).edit().putString("name_prefix", chosen).apply();
                        updateStatus();
                        Toast.makeText(this, "New contacts: " + chosen + " 1, " + chosen + " 2...", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        showCustomPrefixDialog();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showCustomPrefixDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setHint("e.g. OFFICE, CLIENT, SHOP");
        input.setText(getSharedPreferences("csc", MODE_PRIVATE).getString("name_prefix", ""));
        input.setSelectAllOnFocus(true);

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout box = new android.widget.FrameLayout(this);
        box.setPadding(pad, 0, pad, 0);
        box.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Custom Contact Prefix")
                .setMessage("Example: OFFICE → OFFICE 1, OFFICE 2, OFFICE 3")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim().replaceAll("\\s+", " ");
                    if (value.isEmpty()) {
                        Toast.makeText(this, "Prefix khali nahi ho sakta", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (value.length() > 30) value = value.substring(0, 30);
                    getSharedPreferences("csc", MODE_PRIVATE).edit().putString("name_prefix", value).apply();
                    updateStatus();
                    Toast.makeText(this, "New contacts: " + value + " 1, " + value + " 2...", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void requestContacts() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS}, CONTACT_REQ);
        } else {
            Toast.makeText(this, "Contacts permission already allowed", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseGoogleAccount() {
        try {
            Intent intent = android.accounts.AccountManager.newChooseAccountIntent(
                    null, null, new String[]{"com.google"}, null, null, null, null);
            startActivityForResult(intent, ACCOUNT_REQ);
        } catch (Exception e) {
            Toast.makeText(this, "Google account chooser open nahi hua", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ACCOUNT_REQ && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME);
            if (name != null && !name.isEmpty()) {
                getSharedPreferences("csc", MODE_PRIVATE).edit().putString("google_account", name).apply();
                updateStatus();
                Toast.makeText(this, "Contacts is Google account me save honge", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openNotificationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Notification settings open nahi ho paayi", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        refreshHistory();
        updatePermissionButtons();
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                registerReceiver(historyReceiver, new IntentFilter("com.dravesh.cscautosave.HISTORY_UPDATED"), Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(historyReceiver, new IntentFilter("com.dravesh.cscautosave.HISTORY_UPDATED"));
            }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(historyReceiver); } catch (Throwable ignored) { }
        super.onPause();
    }
}
