# CSC Auto Save Android 16 Pro v1.8

Detects WhatsApp notification phone numbers such as `+91 87095 91873`. Saves contacts as CSC 1, CSC 2, etc. with name and phone only. Uses the selected Google account internally. History shows only Name and Phone. Permission buttons hide automatically after permissions are enabled.
