# CSC Auto Save v2.3 Pro

## Contact Name Prefix
Settings → Contact Name Format lets you choose:
- CSC → CSC 1, CSC 2, CSC 3...
- WORK → WORK 1, WORK 2, WORK 3...
- XTZ → XTZ 1, XTZ 2, XTZ 3...
- CUSTOM → any prefix such as OFFICE, CLIENT, SHOP

The selected prefix applies to **new contacts only**. Existing contacts are not renamed.

Other features retained: WhatsApp notification detection, Google Contacts account selection, permission status hiding, and Name + Phone-only history.
