# CSC Auto Save - Android 16 Pro

Android 16 / API 36 compatible build.

## Build on GitHub
1. Upload the project files to a GitHub repository.
2. Open **Actions**.
3. Run **Build CSC Auto Save Android 16 Pro APK**.
4. Download the artifact **CSC-Auto-Save-Android16-Pro-APK**.

## Phone setup
1. Install the APK.
2. Open the app.
3. Allow Contacts permission.
4. Open **Notification Access** and enable CSC Auto Save.
5. Keep WhatsApp notifications enabled.

Note: this version still relies on information exposed by WhatsApp notifications. If WhatsApp does not expose a phone number in a notification, the notification listener cannot magically recover the number from it.
