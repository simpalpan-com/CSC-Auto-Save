# CSC Auto Save: no custom ProGuard rules required.
