# CSC Auto Save 2.0 Android 16 - Fixed

Saves phone numbers detected from WhatsApp notifications as `CSC 1`, `CSC 2`, `CSC 3`... into the selected Google Contacts account.

## Setup
1. Install the APK.
2. Allow Contacts permission.
3. Open **Notification Access** and enable **CSC Auto Save**.
4. Select the Google account where contacts should be created.
5. Keep WhatsApp notifications enabled and visible.
6. Test with a message from an unsaved number.

## Important
The listener supports normal WhatsApp and WhatsApp Business notification package names and checks title, text, big text, text lines, MessagingStyle senders, and Person URIs for phone numbers.


## Fix in 1.4
The phone parser now correctly detects WhatsApp notifications such as `+91 87095 91873` (5+5 digit Indian format). Logcat tag `CSC_AUTO_SAVE` records detection and contact-save errors for troubleshooting.


## History / Contact format
- Google Contacts stores only contact name and phone number.
- The selected Google account is used internally as the contact account and is not shown as an email field.
- App History displays only Name and Phone.
