# CSC Auto Save 1.1

Android app that saves phone numbers found in WhatsApp notifications as CSC 1, CSC 2, CSC 3...

## Setup
1. Install APK.
2. Open the app.
3. Allow Contacts permission.
4. Tap Notification Access ON and enable CSC Auto Save.
5. Keep WhatsApp notifications enabled and visible.

The notification listener is protected with BIND_NOTIFICATION_LISTENER_SERVICE and is not exported.
