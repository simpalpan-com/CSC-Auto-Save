package com.dravesh.cscautosave;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int CONTACT_REQ = 41;
    private static final int ACCOUNT_REQ = 42;
    private HistoryDbHelper historyDb;
    private TextView historyList;
    private TextView historyCount;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            setContentView(R.layout.main);
            historyDb = new HistoryDbHelper(this);
            setupUi();
        } catch (Throwable t) {
            Toast.makeText(this, "CSC Auto Save start error: " + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void setupUi() {
        TextView status = findViewById(R.id.status);
        Button permission = findViewById(R.id.permission);
        Button notif = findViewById(R.id.notif);
        Button reset = findViewById(R.id.reset);
        Button account = findViewById(R.id.account);
        Button clearHistory = findViewById(R.id.clearHistory);
        historyList = findViewById(R.id.historyList);
        historyCount = findViewById(R.id.historyCount);

        permission.setOnClickListener(v -> requestContacts());
        notif.setOnClickListener(v -> openNotificationSettings());
        account.setOnClickListener(v -> chooseGoogleAccount());
        reset.setOnClickListener(v -> {
            getSharedPreferences("csc", MODE_PRIVATE).edit().putInt("next", 1).apply();
            updateStatus();
            Toast.makeText(this, "CSC numbering 1 se start hogi", Toast.LENGTH_SHORT).show();
        });
        clearHistory.setOnClickListener(v -> {
            historyDb.clearToday();
            refreshHistory();
            Toast.makeText(this, "Aaj ki history clear ho gayi", Toast.LENGTH_SHORT).show();
        });
        updateStatus();
        refreshHistory();
    }

    private void updateStatus() {
        TextView s = findViewById(R.id.status);
        if (s != null) {
            String account = getSharedPreferences("csc", MODE_PRIVATE).getString("google_account", null);
            if (account == null) account = "Google account: Auto select";
            s.setText("Next contact: CSC " + getSharedPreferences("csc", MODE_PRIVATE).getInt("next", 1) + "\nSave to: " + account);
        }
    }

    private void refreshHistory() {
        if (historyDb == null || historyList == null) return;
        ArrayList<String> rows = historyDb.getTodayRows();
        if (historyCount != null) historyCount.setText("Aaj Saved: " + rows.size());
        if (rows.isEmpty()) {
            historyList.setText("Aaj abhi koi number save nahi hua.");
            return;
        }
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < rows.size(); i++) {
            out.append(i + 1).append(". ").append(rows.get(i));
            if (i < rows.size() - 1) out.append("\n\n");
        }
        historyList.setText(out.toString());
    }

    private void requestContacts() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS}, CONTACT_REQ);
        } else {
            Toast.makeText(this, "Contacts permission already allowed", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseGoogleAccount() {
        try {
            Intent intent = android.accounts.AccountManager.newChooseAccountIntent(
                    null, null, new String[]{"com.google"}, null, null, null, null);
            startActivityForResult(intent, ACCOUNT_REQ);
        } catch (Exception e) {
            Toast.makeText(this, "Google account chooser open nahi hua", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ACCOUNT_REQ && resultCode == RESULT_OK && data != null) {
            String name = data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME);
            if (name != null && !name.isEmpty()) {
                getSharedPreferences("csc", MODE_PRIVATE).edit().putString("google_account", name).apply();
                updateStatus();
                Toast.makeText(this, "Contacts is Google account me save honge", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openNotificationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Notification settings open nahi ho paayi", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        refreshHistory();
    }
}
