package com.dravesh.cscautosave;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class HistoryDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "csc_history.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "saved_history";

    public HistoryDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, account TEXT, saved_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_saved_at ON " + TABLE + "(saved_at)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 only. Future schema changes can be migrated here.
    }

    public void add(String name, String phone, String account) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("phone", phone);
        v.put("account", account);
        v.put("saved_at", System.currentTimeMillis());
        db.insert(TABLE, null, v);
    }

    public ArrayList<String> getTodayRows() {
        ArrayList<String> rows = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String startText = day + " 00:00:00";
        long start;
        try {
            start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(startText).getTime();
        } catch (Exception e) {
            start = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        }

        Cursor c = db.query(TABLE, new String[]{"name", "phone", "account", "saved_at"},
                "saved_at >= ?", new String[]{String.valueOf(start)}, null, null, "saved_at DESC");
        try {
            SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
            while (c.moveToNext()) {
                String name = c.getString(0);
                String phone = c.getString(1);
                // History intentionally shows only contact name and phone number.
                // Google account is used internally for contact ownership and is not displayed.
                rows.add("Name: " + name + "\nPhone: " + phone);
            }
        } finally {
            c.close();
        }
        return rows;
    }

    public int getTodayCount() {
        return getTodayRows().size();
    }

    public void clearToday() {
        SQLiteDatabase db = getWritableDatabase();
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        long start;
        try {
            start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(day + " 00:00:00").getTime();
        } catch (Exception e) {
            start = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        }
        db.delete(TABLE, "saved_at >= ?", new String[]{String.valueOf(start)});
    }
}
