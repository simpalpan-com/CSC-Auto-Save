package com.dravesh.cscautosave;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Notification;
import android.content.ContentProviderOperation;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WhatsAppNotificationListener extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final Pattern PHONE = Pattern.compile("(?:(?:\\+?91)[\\s-]*)?[6-9]\\d[\\s-]?\\d{4}[\\s-]?\\d{5}|\\+?\\d{10,15}");

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !WA.equals(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;

            CharSequence title = n.extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = n.extras.getCharSequence(Notification.EXTRA_TEXT);
            CharSequence big = n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            String all = value(title) + " " + value(text) + " " + value(big);
            String phone = findPhone(all);
            if (phone == null) return;
            if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) return;
            saveIfNew(phone);
        } catch (Throwable ignored) {
            // Never allow a malformed WhatsApp notification to kill the listener process.
        }
    }

    private String value(CharSequence s) {
        return s == null ? "" : s.toString();
    }

    private String findPhone(String s) {
        Matcher m = PHONE.matcher(s == null ? "" : s);
        while (m.find()) {
            String digits = m.group().replaceAll("\\D", "");
            if (digits.length() == 10 && digits.matches("[6-9]\\d{9}")) return "+91" + digits;
            if (digits.length() >= 10 && digits.length() <= 15) return "+" + digits;
        }
        return null;
    }

    private void saveIfNew(String phone) {
        if (exists(phone)) return;
        SharedPreferences p = getSharedPreferences("csc", MODE_PRIVATE);
        int next = p.getInt("next", 1);
        String name = "CSC " + next;
        try {
            String accountName = p.getString("google_account", null);
            if (accountName == null) accountName = findGoogleAccount();

            ArrayList<ContentProviderOperation> ops = new ArrayList<>();
            ContentProviderOperation.Builder raw = ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI);
            if (accountName != null) {
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, "com.google");
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, accountName);
            } else {
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null);
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null);
            }
            ops.add(raw.build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name).build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build());
            getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
            p.edit().putInt("next", next + 1).apply();
            new HistoryDbHelper(this).add(name, phone, accountName);
        } catch (Exception ignored) { }
    }

    private String findGoogleAccount() {
        try {
            Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
            if (accounts != null && accounts.length > 0) return accounts[0].name;
        } catch (SecurityException ignored) {
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean exists(String phone) {
        Cursor c = null;
        try {
            String digits = phone.replaceAll("\\D", "");
            Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
            c = getContentResolver().query(uri, new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
            if (c == null) return false;
            while (c.moveToNext()) {
                String x = c.getString(0);
                if (x != null && x.replaceAll("\\D", "").equals(digits)) return true;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return false;
    }
}
