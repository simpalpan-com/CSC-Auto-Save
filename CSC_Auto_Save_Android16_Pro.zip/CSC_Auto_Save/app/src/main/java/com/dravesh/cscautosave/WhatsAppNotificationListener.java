package com.dravesh.cscautosave;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Notification;
import android.content.ContentProviderOperation;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads WhatsApp notification content and saves an Indian/mobile phone number
 * into the selected Google Contacts account.
 */
public class WhatsAppNotificationListener extends NotificationListenerService {
    private static final Set<String> WA_PACKAGES = new HashSet<>();
    static {
        WA_PACKAGES.add("com.whatsapp");
        WA_PACKAGES.add("com.whatsapp.w4b");
    }

    // Handles +91XXXXXXXXXX, 91XXXXXXXXXX, and common spaced/hyphenated forms.
    private static final Pattern PHONE = Pattern.compile(
            "(?<!\\d)(?:\\+?91[\\s-]?)?[6-9]\\d[\\s-]?\\d{4}[\\s-]?\\d{5}(?!\\d)"
                    + "|(?<!\\d)\\+\\d{10,15}(?!\\d)"
                    + "|(?<!\\d)\\d{10,15}(?!\\d)"
    );

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !WA_PACKAGES.contains(sbn.getPackageName())) return;

            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;

            String phone = findPhoneInNotification(n);
            if (phone == null) return;

            if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS)
                    != PackageManager.PERMISSION_GRANTED) return;

            saveIfNew(phone);
        } catch (Throwable ignored) {
            // Notification formats vary by WhatsApp version. Never crash the listener.
        }
    }

    private String findPhoneInNotification(Notification n) {
        Bundle e = n.extras;

        // 1) Normal title/text/big text fields.
        StringBuilder all = new StringBuilder();
        append(all, e.getCharSequence(Notification.EXTRA_TITLE));
        append(all, e.getCharSequence(Notification.EXTRA_TEXT));
        append(all, e.getCharSequence(Notification.EXTRA_BIG_TEXT));

        CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) {
            for (CharSequence line : lines) append(all, line);
        }

        String phone = findPhone(all.toString());
        if (phone != null) return phone;

        // 2) MessagingStyle notifications can carry the sender's phone in Person URI.
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            try {
                Bundle[] messageBundles = e.getParcelableArray(Notification.EXTRA_MESSAGES, Bundle.class);
                if (messageBundles != null) {
                    for (Bundle mb : messageBundles) {
                        if (mb == null) continue;
                        CharSequence sender = mb.getCharSequence("sender");
                        phone = findPhone(sender == null ? "" : sender.toString());
                        if (phone != null) return phone;
                    }
                }
            } catch (Throwable ignored) { }
        }

        // 3) Some Android/WhatsApp builds expose people as Person[]/parcelables.
        try {
            android.app.Person[] people = e.getParcelableArray(Notification.EXTRA_PEOPLE_LIST, android.app.Person.class);
            if (people != null) {
                for (android.app.Person person : people) {
                    if (person != null && person.getUri() != null) {
                        phone = findPhone(person.getUri());
                        if (phone != null) return phone;
                    }
                }
            }
        } catch (Throwable ignored) { }

        return null;
    }

    private void append(StringBuilder b, CharSequence s) {
        if (s != null) b.append(s).append(' ');
    }

    private String findPhone(String s) {
        if (s == null || s.isEmpty()) return null;
        Matcher m = PHONE.matcher(s);
        while (m.find()) {
            String digits = m.group().replaceAll("\\D", "");
            if (digits.length() == 10 && digits.matches("[6-9]\\d{9}")) return "+91" + digits;
            if (digits.length() == 12 && digits.startsWith("91")) return "+" + digits;
            if (digits.length() >= 10 && digits.length() <= 15) return "+" + digits;
        }
        return null;
    }

    private void saveIfNew(String phone) {
        if (exists(phone)) return;

        SharedPreferences p = getSharedPreferences("csc", MODE_PRIVATE);
        int next = p.getInt("next", 1);
        String name = "CSC " + next;
        String accountName = p.getString("google_account", null);
        if (accountName == null || accountName.trim().isEmpty()) {
            accountName = findGoogleAccount();
        }

        try {
            ArrayList<ContentProviderOperation> ops = new ArrayList<>();
            ContentProviderOperation.Builder raw =
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI);

            if (accountName != null && !accountName.trim().isEmpty()) {
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, "com.google");
                raw.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, accountName);
            }

            ops.add(raw.build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                    .build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build());

            getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
            p.edit().putInt("next", next + 1).apply();
            new HistoryDbHelper(this).add(name, phone, accountName);
        } catch (Exception ignored) {
            // If Google account insertion fails, do not increment CSC number or history.
        }
    }

    private String findGoogleAccount() {
        try {
            Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
            if (accounts != null && accounts.length > 0) return accounts[0].name;
        } catch (Throwable ignored) { }
        return null;
    }

    private boolean exists(String phone) {
        Cursor c = null;
        try {
            String digits = phone.replaceAll("\\D", "");
            c = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, null);
            if (c == null) return false;
            while (c.moveToNext()) {
                String x = c.getString(0);
                if (x != null && x.replaceAll("\\D", "").equals(digits)) return true;
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }
        return false;
    }
}
